
import javax.swing.*;

import javax.swing.table.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.*;

public class user extends JInternalFrame implements ActionListener, MouseListener{

	Vector<Vector<Object>> tableContent;
	Vector<Object> tableRow, tableHeader;

	JPanel panelContainer, panelTabel, panelTotal, panelTitle, panelField, panelButton;

	JLabel lblTitle, lblTitle2, lblId, lblIdIsi, lblStatus, lblStatusIsi, lblName, lblNameIsi,
		lblTransaction, lblTransactionIsi, lblEmail, lblEmailIsi, lblCart, lblCartIsi;

	JButton btnBan, btnUnBan;
	
	JTable table = new JTable();
	
	JScrollPane pane;
	
	DefaultTableModel tableModel;
	
	Connect con = new Connect();

	public void addData(String id, String name, String email, String birthday, String gender, String status) {
		tableRow = new Vector<>();
		tableRow.add(id);
		tableRow.add(name);
		tableRow.add(email);
		tableRow.add(birthday);
		tableRow.add(gender);
		tableRow.add(status);
		tableContent.add(tableRow);
	}

	public void viewData() {
		tableContent = new Vector<>();
		tableHeader = new Vector<>();

		tableHeader.add("ID");
		tableHeader.add("Name");
		tableHeader.add("Email");
		tableHeader.add("Birthday");
		tableHeader.add("Gender");
		tableHeader.add("Status");

		String query = "SELECT * FROM register";
		con.rs = con.executeQuery(query);

		try {
			while (con.rs.next()) {
				addData(con.rs.getString(6), con.rs.getString(1), con.rs.getString(2), con.rs.getString(5), con.rs.getString(4), con.rs.getString(7));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		tableModel = new DefaultTableModel(tableContent, tableHeader);

		table.setModel(tableModel);

		tableModel.fireTableDataChanged();
		
		table.addMouseListener(this);

	}

	public void initComponent() {
		viewData();

		table.setAutoCreateRowSorter(true);

		pane = new JScrollPane(table);
		
		panelContainer = new JPanel(new GridLayout(2, 1));
		panelTabel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelTotal = new JPanel(new GridLayout(3, 1));
		panelTitle = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelField = new JPanel(new GridLayout(3, 4));
		panelButton = new JPanel(new FlowLayout(FlowLayout.CENTER));
		
		lblTitle = new JLabel("Manage User");
		lblTitle.setFont(new Font("Sans", Font.BOLD,20));
		
		lblTitle2 = new JLabel("User Detail");
		lblTitle2.setFont(new Font("Sans", Font.BOLD,20));
		
		lblId = new JLabel("ID");
		lblIdIsi = new JLabel("Isi Id");
		
		lblStatus = new JLabel("Status");
		lblStatusIsi = new JLabel("Isi Status");
		
		lblName = new JLabel("Name");
		lblNameIsi = new JLabel("Isi Name");
		
		lblTransaction = new JLabel("Transaction");
		lblTransactionIsi = new JLabel("Isi Transaction");
		
		lblEmail = new JLabel("Email");
		lblEmailIsi = new JLabel("Isi Email");
		
		lblCart = new JLabel("Cart");
		lblCartIsi = new JLabel("Isi Cart");

		

		btnBan = new JButton("Ban User");
		btnBan.addActionListener(this);
		
		btnUnBan = new JButton("Un-Ban User");
		btnUnBan.addActionListener(this);

	}

	public void setComponent() {
		panelTabel.add(lblTitle);
		
		panelTabel.add(pane, "Center");
		
		panelTitle.add(lblTitle2);
		
		panelField.add(lblId);
		panelField.add(lblIdIsi);
		
		panelField.add(lblStatus);
		panelField.add(lblStatusIsi);
		
		panelField.add(lblName);
		panelField.add(lblNameIsi);
		
		panelField.add(lblTransaction);
		panelField.add(lblTransactionIsi);
		
		panelField.add(lblEmail);
		panelField.add(lblEmailIsi);
		
		panelField.add(lblCart);
		panelField.add(lblCartIsi);
		
		
		panelButton.add(btnBan);
		panelButton.add(btnUnBan);
	
		
		panelTotal.add(panelTitle);
		panelTotal.add(panelField);
		panelTotal.add(panelButton);
		
		panelContainer.add(panelTabel);
		panelContainer.add(panelTotal);
		
		this.add(panelContainer,"Center");
		
	}

	public user() {
		this.setLayout(new BorderLayout());
		this.setTitle("Products");
		this.setSize(500, 500);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setVisible(true);
		initComponent();
		setComponent();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		String id = lblIdIsi.getText();
		String query2 = "UPDATE register SET status = 'Banned' WHERE idUser LIKE '"+id+"'";
		String query3 = "UPDATE register SET status = 'Active' WHERE idUser LIKE '"+id+"'";
		
		if(e.getSource() == btnBan){
			con.executeUpdate(query2);
			viewData();
		}else if(e.getSource() == btnUnBan){
			con.executeUpdate(query3);
			viewData();
		}
		
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(table.getSelectedRow() != -1){
			String idUser = table.getValueAt(table.getSelectedRow(), 0).toString();
			String query2 = "SELECT COUNT(TransactionID) AS idTransaction FROM headertransaction WHERE UserID LIKE '"+idUser+"'";
			String query3 = "SELECT COUNT(UserID) AS idUser FROM mycart WHERE UserID LIKE '"+idUser+"'";
			con.rs = con.executeQuery(query2);
			
			
			
			lblIdIsi.setText(table.getValueAt(table.getSelectedRow(), 0).toString());
			lblStatusIsi.setText(table.getValueAt(table.getSelectedRow(), 5).toString());
			lblNameIsi.setText(table.getValueAt(table.getSelectedRow(), 1).toString());
			try {
				while (con.rs.next()) {
					lblTransactionIsi.setText(con.rs.getString("idTransaction"));
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			lblEmailIsi.setText(table.getValueAt(table.getSelectedRow(), 2).toString());
			
			con.rs = con.executeQuery(query3);
			try {
				while (con.rs.next()) {
					System.out.println(con.rs.getString("idUser"));
					lblCartIsi.setText(con.rs.getString("idUser"));
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
		}
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {
		// TODO Auto-generated method stub
		
	}

}

