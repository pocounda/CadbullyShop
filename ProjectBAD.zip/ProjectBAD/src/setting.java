import javax.swing.*;

import javax.swing.table.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.*;

public class setting extends JInternalFrame implements ActionListener, MouseListener{

	JPanel panelContainer, panelTitle, panelField, panelButton;
	
	JLabel labelTitle, labelOPassword, labelNPassword, labelCPassword;
	
	JPasswordField txtOPassword, txtNPassword, txtCPassword;
	
	JButton btnUpdate;

	Connect con = new Connect();

	
	public void initComponent() {
		// fungsi buat create component
		
		panelContainer = new JPanel(new GridLayout(3, 1));
		panelTitle = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelField = new JPanel(new GridLayout (3, 2));
		panelButton = new JPanel(new FlowLayout(FlowLayout.CENTER));
		
		
		labelTitle = new JLabel("Change Password");
		labelTitle.setFont(new Font("Sans", Font.BOLD,20));
		
		labelOPassword = new JLabel("Enter Old Password");
		labelNPassword = new JLabel("Enter New Password");
		labelCPassword = new JLabel("Confirm Password");

		txtOPassword = new JPasswordField();
		txtNPassword = new JPasswordField();
		txtCPassword = new JPasswordField();

		btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(this);

	}

	public void setComponent() {
		panelTitle.add(labelTitle);
		
		panelField.add(labelOPassword);
		panelField.add(txtOPassword);		
		panelField.add(labelNPassword);
		panelField.add(txtNPassword);		
		panelField.add(labelCPassword);
		panelField.add(txtCPassword);

		panelButton.add(btnUpdate);
		
		panelContainer.add(panelTitle);
		panelContainer.add(panelField);
		panelContainer.add(panelButton);
		
		this.add(panelContainer,"Center");
		
	}

	public setting() {
		this.setLayout(new BorderLayout());
		this.setTitle("Products");
		this.setSize(400, 250);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setVisible(true);
		initComponent();
		setComponent();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == btnUpdate){
			String query2 = "SELECT * FROM `register` WHERE `idUser` LIKE '"+masuk.userId+"'";
					con.rs = con.executeQuery(query2);
					System.out.println(masuk.userId);
			//String password = txtNPassword.getText();
			try {
				while(con.rs.next()){
					if(!txtOPassword.getText().equals(con.rs.getString("password"))){
						JOptionPane.showMessageDialog(this, "Your password doesn't match with your current password!", "Error", JOptionPane.ERROR_MESSAGE);
					}else if(txtNPassword.getText().length() <10){
						JOptionPane.showMessageDialog(this, "Your password must be 10!", "Error", JOptionPane.ERROR_MESSAGE);
					}else if(txtOPassword.getText().equals(txtNPassword.getText())){
						JOptionPane.showMessageDialog(this, "Your password can't be same!", "Error", JOptionPane.ERROR_MESSAGE);
					}else if(!txtNPassword.getText().equals(txtCPassword.getText())){
						JOptionPane.showMessageDialog(this, "Your password doesn't match!", "Error", JOptionPane.ERROR_MESSAGE);
					}else{
						String query3 = "UPDATE `register` SET `password`= '"+txtNPassword.getText()+"' WHERE `idUser` LIKE '"+masuk.userId+"'";
						con.executeUpdate(query3);
						JOptionPane.showMessageDialog(this, "Password has been changed!");
						remove(panelContainer);
					}
				}
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			
		}
		
	}

}

