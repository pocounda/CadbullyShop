import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;
import java.util.Arrays;
import java.util.Vector;

import javax.swing.*;

import com.mysql.jdbc.ResultSet;

public class Menu extends JFrame implements ActionListener{
	
	JFrame frame1 = new JFrame();
	JFrame frame2 = new JFrame();
	JPanel pnlMenu, pnlTitle, pnlEmail, pnlPassword, pnlTombol, pnlRegister;
	JLabel lblTitle, lblEmail, lblPassword;
	JButton register, login, back, submit;
	JPanel pnlName, pnlCpassword, pnlGender1 = null, pnlGender2, pnlGender3, pnlBirthday1, pnlBirthday2, pnlBirthday3, pnlTnc, pnlButton = null, pnltxtFEmail;
	JLabel lblName, lblCpassword, lblGender, lblBirthday, lblTnc;
	JTextField txtName, txtEmail;
	JPasswordField txtPassword, txtCpassword;
	JRadioButton male, female;
	JComboBox cmbDay, cmbMonth, cmbYear;
	Vector<String> day, month, year;
	//String[] month = {"Month", "January", "February", "March", "April", "May","June", "July", "August", "September", "October", "November","December"};
	JCheckBox tnc;
	ButtonGroup genderGroup;
	
	Connect con = new Connect();
	
	JMenuBar menuBar = new JMenuBar();
	JMenuBar menuBar1 = new JMenuBar();	
	JMenu menu = new JMenu("Store");
	JMenu menuProfile = new JMenu("Profile");
	JMenuItem menuProducts = new JMenuItem("Products");
	JMenuItem menuCart = new JMenuItem("Cart");
	JMenuItem menuHampers = new JMenuItem("Hampers");
	JMenuItem menuAbout = new JMenuItem("About");
	JMenuItem menuChangePassword = new JMenuItem("Change Password");
	JMenuItem menuLogout = new JMenuItem("Logout");
	JMenuItem menuLogout1 = new JMenuItem("Logout");
	
	JMenu menu1 = new JMenu("Manage");
	JMenuItem menuUser = new JMenuItem("User");
	JMenuItem menuItem = new JMenuItem("Item");

	
	JToolBar toolBar = new JToolBar();
	
	
	JDesktopPane content = new JDesktopPane();
	user User;
	item Item;
	
	
	product Product;
	cart Cart;
	setting Setting;

	
	void login(){
		
	//==========================================================
		
			lblTitle = new JLabel("SIGN IN");
			lblTitle.setFont(new Font("Sans", Font.BOLD,20));
			lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
			pnlTitle = new JPanel(new FlowLayout (FlowLayout.CENTER));
			pnlTitle.add(lblTitle);
			
		
			lblEmail = new JLabel("Email : ");
			txtEmail = new JTextField(15);
			pnlEmail = new JPanel(new GridLayout (1,2));
			pnlEmail.add(lblEmail);
			pnlEmail.add(txtEmail);
			
		
			lblPassword = new JLabel("Password : ");
			txtPassword = new JPasswordField(15);
			pnlPassword = new JPanel(new GridLayout (1,2));
			pnlPassword.add(lblPassword);
			pnlPassword.add(txtPassword);
		
		
			register = new JButton("Register");
			login = new JButton("Login");
			pnlTombol = new JPanel(new FlowLayout (FlowLayout.CENTER));
			pnlTombol.add(register);
			register.addActionListener(this);
			pnlTombol.add(login);
			login.addActionListener(this);
	//==========================================================		
		pnlMenu = new JPanel (new GridLayout(4, 2));
		//pnlMenu.setBackground(Color.GRAY);
		pnlMenu.add(pnlTitle);
		pnlMenu.add(pnlEmail);
		pnlMenu.add(pnlPassword);
		pnlMenu.add(pnlTombol);
	//==========================================================	
			
		setTitle("Cadbully Shop");
		setSize(new Dimension (350,160));
		setLayout(new BorderLayout());
		add(pnlMenu, BorderLayout.CENTER);
		setLocationRelativeTo(null);
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		setResizable(false);
		setVisible(true);
	}
	
	void registerBaru(){
		//========================================================
		
			lblTitle = new JLabel("CREATE ACCOUNT");
				lblTitle.setFont(new Font("Sans", Font.BOLD,20));
				lblTitle.setHorizontalAlignment(SwingConstants.CENTER);
			
		
			lblName = new JLabel("Name : ");
			txtName = new JTextField(15);
			pnlName = new JPanel(new GridLayout(1,2));
			pnlName.add(lblName);
			pnlName.add(txtName);
			
			
			lblEmail = new JLabel("Email : ");
			txtEmail = new JTextField(15);
			pnlEmail = new JPanel(new GridLayout(1,2));
			pnlEmail.add(lblEmail);
			pnlEmail.add(txtEmail);
			

			lblPassword = new JLabel("Password : ");
			txtPassword = new JPasswordField(15);
			pnlPassword = new JPanel(new GridLayout(1,2));
			pnlPassword.add(lblPassword);
			pnlPassword.add(txtPassword);
			

			lblCpassword = new JLabel("Confirm Password : ");
			txtCpassword = new JPasswordField(15);
			pnlCpassword = new JPanel(new GridLayout(1,2));
			pnlCpassword.add(lblCpassword);
			pnlCpassword.add(txtCpassword);

		
			lblGender = new JLabel("Gender : ");
			male = new JRadioButton("Male");
			female = new JRadioButton("Female");
			genderGroup = new ButtonGroup();
			genderGroup.add(male);
			genderGroup.add(female);			
			pnlGender1 = new JPanel(new GridLayout(1,1));
			pnlGender2 = new JPanel(new GridLayout(1,1));	
			pnlGender3 = new JPanel(new GridLayout(1,1));
			pnlGender1.add(lblGender);
			pnlGender2.add(female);
			pnlGender2.add(male);
			pnlGender3.add(pnlGender1);
			pnlGender3.add(pnlGender2);
		
		
		
			lblBirthday = new JLabel("Birthday : ");
			
			day = new Vector<>();
			month = new Vector<>();
			year = new Vector<>();
			
			day.add("Day");	
			month.add("Month");
			year.add("Year");
				
			for (int i = 1; i <= 31; i++) {
				day.add(""+ i);
			}
			
			for (int i = 1990; i <= 2019; i++) {
				year.add(""+ i);
			}
			
			for (int i = 1; i <= 12; i++) {
				month.add(""+ i);
			}
			
			cmbDay = new JComboBox<>(day);
			cmbMonth = new JComboBox<>(month);
			cmbYear = new JComboBox<>(year);	
			
			pnlBirthday1 = new JPanel(new GridLayout(1,1));
			pnlBirthday2 = new JPanel(new GridLayout(1,1));
			pnlBirthday3 = new JPanel(new GridLayout(1,1));
			pnlBirthday1.add(lblBirthday);
			pnlBirthday2.add(cmbDay);
			pnlBirthday2.add(cmbMonth);
			pnlBirthday2.add(cmbYear);
			pnlBirthday3.add(pnlBirthday1);
			pnlBirthday3.add(pnlBirthday2);
			
		
			lblTnc = new JLabel("Terms and Condition");
			tnc = new JCheckBox();
			pnlTnc = new JPanel(new FlowLayout(FlowLayout.CENTER));
			pnlTnc.add(tnc);
			pnlTnc.add(lblTnc);
			
		
			back = new JButton("Back");
			submit = new JButton("Submit");
			pnlButton = new JPanel(new FlowLayout(FlowLayout.CENTER));
			pnlButton.add(back);
			back.addActionListener(this);
			pnlButton.add(submit);
			submit.addActionListener(this);
		//========================================================
		pnlRegister = new JPanel(new GridLayout(9,1));
		pnlRegister.add(lblTitle);
		pnlRegister.add(pnlName);
		pnlRegister.add(pnlEmail);
		pnlRegister.add(pnlPassword);
		pnlRegister.add(pnlCpassword);
		pnlRegister.add(pnlGender3);
		pnlRegister.add(pnlBirthday3);		
		pnlRegister.add(pnlTnc);		
		pnlRegister.add(pnlButton);		
		//========================================================
			setTitle("Cadbully Shop");
			setSize(new Dimension (400,450));
			setLayout(new BorderLayout());
			add(pnlRegister, BorderLayout.CENTER);
			setLocationRelativeTo(null);
			setDefaultCloseOperation(EXIT_ON_CLOSE);
			setResizable(false);
			setVisible(true);
	}
	
	public void generateToolBar()
	{
		
		toolBar.setFloatable(false);
	}
	
	public void generateMenu()
	{
		menuBar1.add(menu);
		menu.add(menuProducts);
		menu.add(menuCart);
		menu.add(menuHampers);
		menu.addSeparator();
		menu.add(menuAbout);
		
		menuBar1.add(menuProfile);
		menuProfile.add(menuChangePassword);
		menuProfile.add(menuLogout1);
		
		menuProducts.addActionListener(this);
		menuCart.addActionListener(this);
		menuChangePassword.addActionListener(this);
		menuLogout1.addActionListener(this);
		
	}
	
	public void MainForm() {
		frame2.setTitle("Cadbully Shop");
		
		frame2.setJMenuBar(menuBar1);
		generateMenu();
		
		frame2.add(toolBar, "North");
		generateToolBar();
		
		frame2.setContentPane(content);
		
		frame2.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame2.setExtendedState(MAXIMIZED_BOTH);
		frame2.setVisible(true);
		frame2.setContentPane(new JLabel(new ImageIcon(getClass().getResource("/images/chocolate_cup_coffee_morning_88253_240x320.jpg"))));
	}

	public void generateToolBar1()
	{
		
	}
	
	public void generateMenu1()
	{
		menuBar.add(menu1);
		menu1.add(menuUser);
		menu1.add(menuItem);
		menu1.addSeparator();
		menu1.add(menuLogout);
		
		
		menuUser.addActionListener(this);
		menuItem.addActionListener(this);
		menuLogout.addActionListener(this);
		
	}
	
	public void MainForm1() {
		frame1.setTitle("Cadbully Shop");
		
		frame1.setJMenuBar(menuBar);
		generateMenu1();
		
		frame1.add(toolBar, "North");
		generateToolBar1();
		
		frame1.setContentPane(content);
		
		frame1.setDefaultCloseOperation(EXIT_ON_CLOSE);
		frame1.setExtendedState(MAXIMIZED_BOTH);
		frame1.setVisible(true);
		frame1.setContentPane(new JLabel(new ImageIcon(getClass().getResource("/images/chocolate_cup_coffee_morning_88253_240x320.jpg"))));
	}
	
	public void actionPerformed(ActionEvent e){
		if(e.getSource() == register){
			remove(pnlMenu);
			registerBaru();
		}
		
		if(e.getSource() == back){
			remove(pnlRegister);
			login();	
		}
		
		if(e.getSource() == submit){
			if(txtName.getText().isEmpty()){
				JOptionPane.showMessageDialog(this, "Name mustn't be empty!");
				
			}else if(txtName.getText().length()<5 || txtName.getText().length()>25){
				JOptionPane.showMessageDialog(this, "Name must be between 5 and 25!");
				
			}else if(txtEmail.getText().isEmpty()){
				JOptionPane.showMessageDialog(this, "Email mustn't be empty!");
				
			}else if(txtEmail.getText().contains("@.") || txtEmail.getText().contains(".@") || txtEmail.getText().startsWith("@") 
					|| txtEmail.getText().startsWith(".") || !txtEmail.getText().endsWith(".com") || !txtEmail.getText().contains("@")){
						JOptionPane.showMessageDialog(this, "Email is Wrong!");
						
			}else if(txtPassword.getPassword().length<10 || txtPassword.getPassword().length<1){
				JOptionPane.showMessageDialog(this, "Password must be more than 10 and not null!");
				
			}else if(!Arrays.equals(txtPassword.getPassword(), txtCpassword.getPassword())){
				JOptionPane.showMessageDialog(this, "Password must be same!");
				
			}else if(!male.isSelected()  && !female.isSelected()){
				JOptionPane.showMessageDialog(this, "Gender musn't be null!");
				
			}else if(cmbDay.getSelectedIndex() == 0 && cmbMonth.getSelectedIndex() == 0 && cmbYear.getSelectedIndex() == 0){
				JOptionPane.showMessageDialog(this, "Birthday musn't be null and more than 18 years old!");
				
			}else if(!tnc.isSelected()){
				JOptionPane.showMessageDialog(this, "You must check terms and condition box!");
			}else{
			
				String query1 = "";
				String name = txtName.getText();
				String email = txtEmail.getText();
				String password = new String(txtPassword.getPassword());
				String gender = null;
				if(male.isSelected()){
					gender = "M";
				}else if(female.isSelected()){
					gender = "F";
				}
			
				String day = (String) cmbDay.getSelectedItem();
				String month = (String) cmbMonth.getSelectedItem();
				String year = (String) cmbYear.getSelectedItem();
				
				String date = year+"-"+ month +"-"+ day;
			
				String userId = "";
				
				try {
					query1 = "SELECT RIGHT(idUser, 3) AS userID FROM register ORDER BY idUser DESC LIMIT 1";
			
					con = new Connect();
					
					con.rs = con.executeQuery(query1);
					
					while (con.rs.next()) {
						String helo = con.rs.getString("userID");
						if(helo == null){
							userId = "US001";
						}else{
							int id = Integer.parseInt(helo) + 1;
						
							if(id < 10 || id > 0){
								userId = "US00"+ Integer.toString(id);
							}else if(id > 9 || id < 100){
								userId = "US0"+ Integer.toString(id);
							}else if(id > 99 || id < 1000){
								userId = "US"+ Integer.toString(id);
							}
						}
					}	
				} catch (SQLException x) {
					x.printStackTrace();
				}
				
				
			
				String query3 = "INSERT INTO `register`(`name`, `email`, `password`, `gender`, `date`, `idUser`,`status`,`role`) "
						+ "VALUES ('"+name+"','"+email+"','"+password+"','"+gender+"','"+date+"','"+userId+"','Active','User')";
				
				JOptionPane.showMessageDialog(this, "Account has been created!");
				
				con.executeUpdate(query3);
				remove(pnlRegister);
				login();	
			}
		}
		
		if(e.getSource() == login){
			if(txtEmail.getText().isEmpty()){
				JOptionPane.showMessageDialog(this, "Email musn't be null");
			}else if(txtPassword.getPassword().length < 1){
				JOptionPane.showMessageDialog(this, "Password musn't be null");
			}else if(txtEmail.getText().contains("@.") || txtEmail.getText().contains(".@") || txtEmail.getText().startsWith("@") 
					|| txtEmail.getText().startsWith(".") || !txtEmail.getText().endsWith(".com") || !txtEmail.getText().contains("@")){
				JOptionPane.showMessageDialog(this, "Invalid email!");
			}else{
				String query8 = "SELECT * FROM register";
				String email = txtEmail.getText();
				String password = new String(txtPassword.getPassword());
				String query5 = "SELECT * FROM register WHERE email = '"+email+"' AND password = '"+password+"'";
				
				con.rs = con.executeQuery(query5);
				try {
					while(con.rs.next()){
						if(con.rs.getString("idUser").isEmpty()){
							JOptionPane.showMessageDialog(this, "Invalid email / password!");
						}else if(con.rs.getString("status").equals("Banned")){
							JOptionPane.showMessageDialog(this, "Your Account is being suspended. Please contact us for more info", "Account Suspended", JOptionPane.ERROR_MESSAGE);
						}else if(con.rs.getString("role").equals("Admin")){
							JOptionPane.showMessageDialog(this, "Welcome "+ txtEmail.getText());
							remove(pnlMenu);
							MainForm1();
						}else if(con.rs.getString("role").equals("User")){
							JOptionPane.showMessageDialog(this, "Welcome "+ txtEmail.getText());
							System.out.print(con.rs.getString("idUser"));
							remove(pnlMenu);
							masuk.userId = con.rs.getString("idUser");
							MainForm();
						}
					}
				} catch (SQLException e1) {
					e1.printStackTrace();
				}
				
			}
		}else if(e.getSource()==menuProducts){
			if(Product ==null || Product.isClosed()){
			Product = new product();
			content.add(Product);
			frame2.setContentPane(content);;
			}
		}else if(e.getSource() == menuCart){
			if(Cart ==null || Cart.isClosed()){
			Cart = new cart();
			content.add(Cart);
			frame2.setContentPane(content);;
			}
		}else if(e.getSource() == menuChangePassword){
			if(Setting ==null || Setting.isClosed()){
			Setting = new setting();
			content.add(Setting);
			frame2.setContentPane(content);;
			}
		}if(e.getSource() == menuUser){
			if(User ==null || User.isClosed()){
			User = new user();
			content.add(User);
			frame1.setContentPane(content);;
			}
		}else if(e.getSource() == menuItem){
			if(Item ==null || Item.isClosed()){
			Item = new item();
			content.add(Item);
			frame1.setContentPane(content);;
			}
		}else if(e.getSource() == menuLogout){
			int result = JOptionPane.showConfirmDialog(this, "Are you sure want to logout?","Warning", JOptionPane.YES_NO_OPTION);
			if(result == JOptionPane.YES_OPTION){
				this.setJMenuBar(null);
				login();
			}
		}else if(e.getSource() == menuLogout1){
			int result = JOptionPane.showConfirmDialog(this, "Are you sure want to logout?","Warning", JOptionPane.YES_NO_OPTION);
			if(result == JOptionPane.YES_OPTION){
				this.setJMenuBar(null);
				login();
			}
		}
	}
	
	public Menu() {
		login();
	}

	public static void main(String[] args) {
		new Menu();
	}

}
