import javax.swing.*;

import javax.swing.table.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.*;

public class product extends JInternalFrame implements ActionListener, MouseListener{

	Vector<Vector<Object>> tableContent;
	Vector<Object> tableRow, tableHeader;

	JPanel panelTitle,panelPic, panelInfo, panelTable, panelField, panelButton, panelContainer, panelTotal;

	JLabel labelTitle, labelPic, labelInfo, labelId, labelName, labelQuantity, labelPrice, labelIdIsi, labelNameIsi, labelQuantityIsi, labelPriceIsi;

	JTextField txtId, txtName, txtQuantity, txtPrice;

	JTable table = new JTable();

	DefaultTableModel tableModel;

	JScrollPane pane;

	JButton buttonReset, buttonAdd;
	
	JSpinner quantity;

	int txtNameCounter = 0;

	Connect con = new Connect();

	public void addData(String id, String name, String type, int price) {
		tableRow = new Vector<>();
		tableRow.add(id);
		tableRow.add(name);
		tableRow.add(type);
		tableRow.add(price);
		tableContent.add(tableRow);
	}

	public void viewData() {
		tableContent = new Vector<>();
		tableHeader = new Vector<>();

		tableHeader.add("Product Id");
		tableHeader.add("Product Name");
		tableHeader.add("Product Type");
		tableHeader.add("Product Price");

		String query = "SELECT * FROM item";
		con.rs = con.executeQuery(query);

		try {
			while (con.rs.next()) {
				addData(con.rs.getString(1), con.rs.getString(2), con.rs.getString(4), con.rs.getInt(3));
			}
		} catch (SQLException e){
			e.printStackTrace();
		}

		tableModel = new DefaultTableModel(tableContent, tableHeader);

		table.setModel(tableModel);

		tableModel.fireTableDataChanged();
		
		table.addMouseListener(this);

	}

	public void initComponent() {
		// fungsi buat create component
		viewData();

		table.setAutoCreateRowSorter(true);

		pane = new JScrollPane(table);
		
		panelContainer = new JPanel(new GridLayout(2, 1, 0, 40));
		panelTitle = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelTable = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelTotal = new JPanel(new GridLayout(1, 2));
		panelField = new JPanel(new GridLayout(5, 2, 10, 10));
		panelPic = new JPanel();
		
		labelTitle = new JLabel("Our Products");
		labelTitle.setFont(new Font("Sans", Font.BOLD,20));
		
		labelId = new JLabel("ID:");
		labelName = new JLabel("Name:");
		labelPrice = new JLabel("Price:");
		labelQuantity = new JLabel("Quantity:");
		labelPic = new JLabel("Picture");

		labelIdIsi = new JLabel("");
		labelNameIsi = new JLabel("");
		labelPriceIsi = new JLabel("");
		quantity = new JSpinner();

		buttonReset = new JButton("Reset");
		buttonReset.addActionListener(this);
		
		buttonAdd = new JButton("Add to cart");
		buttonAdd.addActionListener(this);
	}

	public void setComponent() {
		panelTable.add(labelTitle);
		
		panelTable.add(pane, "Center");
		
		panelField.add(labelId);
		panelField.add(labelIdIsi);
		panelField.add(labelName);
		panelField.add(labelNameIsi);
		panelField.add(labelPrice);
		panelField.add(labelPriceIsi);
		panelField.add(labelQuantity);
		panelField.add(quantity);
		
		//panelField.add(panelPic);
		//panelField.add(panelInfo);
		
		panelField.add(buttonReset);
		panelField.add(buttonAdd);
		
		panelPic.add(labelPic);
		
		panelTotal.add(panelPic);
		panelTotal.add(panelField);
		
		//panelContainer.add(panelTitle);
		panelContainer.add(panelTable);
		panelContainer.add(panelTotal);
		
		this.add(panelContainer,"Center");
		
	}

	public product() {
		this.setLayout(new BorderLayout());
		this.setTitle("Products");
		this.setSize(500, 500);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setVisible(true);
		initComponent();
		setComponent();
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == buttonAdd){
			int vQuantity = (int) quantity.getValue();
			if(vQuantity < 1){
				JOptionPane.showMessageDialog(this, "Quantity mustn't be null!", "Error", JOptionPane.ERROR_MESSAGE);
			}else if(vQuantity > 10){
				JOptionPane.showMessageDialog(this, "Quantity must less than 10!", "Error", JOptionPane.ERROR_MESSAGE);
			}else if(labelIdIsi.equals("") || labelNameIsi.equals("") || labelPriceIsi.equals("")){
				JOptionPane.showMessageDialog(this, "Please choose a product!");
			}else{
				String id = labelIdIsi.getText();
				String name = labelNameIsi.getText();
				String price = labelPriceIsi.getText();
				
				String query2 = "INSERT INTO `cart`(`idProduct`, `cName`, `cPrice`, `cQuantity`,`idUser`) VALUES ('"+id+"','"+name+"','"+price+"','"+vQuantity+"','"+masuk.userId+"')";
				String query3 = "INSERT INTO `mycart`(`UserID`, `ProductID`, `ProductQuantity`) VALUES ('"+masuk.userId+"','"+id+"','"+vQuantity+"')";
				con.executeUpdate(query2);
				con.executeUpdate(query3);
				JOptionPane.showMessageDialog(this, "Product has been added to cart!");
				viewData();
			}
		}else if(e.getSource() == buttonReset){
			int result = JOptionPane.showConfirmDialog(this, "Are you sure want to reset?","Warning", JOptionPane.YES_NO_OPTION);
			if(result == JOptionPane.YES_OPTION){
				labelIdIsi.setText("");
				labelNameIsi.setText("");
				labelPriceIsi.setText("");
			}
		}
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(table.getSelectedRow() != -1){
			labelIdIsi.setText(table.getValueAt(table.getSelectedRow(), 0).toString());
			labelNameIsi.setText(table.getValueAt(table.getSelectedRow(), 1).toString());
			labelPriceIsi.setText(table.getValueAt(table.getSelectedRow(), 3).toString());
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

}

