import javax.swing.*;

import javax.swing.table.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.*;

public class cart extends JInternalFrame implements ActionListener, MouseListener{

	Vector<Vector<Object>> tableContent;
	Vector<Object> tableRow, tableHeader;

	JPanel panelTitle, panelTable, panelField, panelButton, panelContainer, panelTotal;

	JLabel labelTitle, labelPic, labelInfo, labelId, labelName, labelQuantity, labelPrice;

	JLabel labelNameIsi, labelPriceIsi;
	
	JTextField txtId, txtName, txtQuantity, txtPrice;

	JTable table = new JTable();

	DefaultTableModel tableModel;

	JScrollPane pane;

	JButton buttonDelete, buttonCheckout;
	
	JSpinner quantity;

	int txtNameCounter = 0;

	Connect con = new Connect();

	public void addData(String id, String name, int price, int quantity) {
		tableRow = new Vector<>();
		tableRow.add(id);
		tableRow.add(name);
		tableRow.add(price);
		tableRow.add(quantity);
		tableContent.add(tableRow);
	}

	public void viewData() {
		tableContent = new Vector<>();
		tableHeader = new Vector<>();

		tableHeader.add("Product Id");
		tableHeader.add("Product Name");
		tableHeader.add("Product Price");
		tableHeader.add("Product Quantity");

		String query = "SELECT * FROM cart WHERE idUser LIKE '"+masuk.userId+"'";
		con.rs = con.executeQuery(query);

		try {
			while (con.rs.next()) {
				addData(con.rs.getString(1), con.rs.getString(2), con.rs.getInt(3), con.rs.getInt(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}

		tableModel = new DefaultTableModel(tableContent, tableHeader);

		table.setModel(tableModel);

		tableModel.fireTableDataChanged();
		
		table.addMouseListener(this);

	}

	public void initComponent() {
		viewData();

		table.setAutoCreateRowSorter(true);

		pane = new JScrollPane(table);
		
		panelContainer = new JPanel(new GridLayout(2, 1, 0, 15));
		panelTitle = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelTable = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelTotal = new JPanel(new GridLayout(1, 2, 10, 0));
		panelField = new JPanel(new GridLayout(3, 2, 10, 10));
		panelButton = new JPanel(new GridLayout(2, 1, 10, 10));
		
		
		labelTitle = new JLabel("Cart");
		labelTitle.setFont(new Font("Sans", Font.BOLD,20));
		
		labelName = new JLabel("Name:");
		labelQuantity = new JLabel("Quantity:");
		labelPrice = new JLabel("Price:");

		labelNameIsi = new JLabel("Isi Nama");
		labelPriceIsi = new JLabel("Isi Harga");
		
		quantity = new JSpinner();

		buttonDelete = new JButton("Delete");
		buttonDelete.addActionListener(this);
		
		buttonCheckout = new JButton("Check Out");
		buttonCheckout.addActionListener(this);

	}

	public void setComponent() {
		panelTable.add(labelTitle);
		
		panelTable.add(pane, "Center");
		
		panelField.add(labelName);
		panelField.add(labelNameIsi);
		panelField.add(labelQuantity);
		panelField.add(quantity);
		panelField.add(labelPrice);
		panelField.add(labelPriceIsi);
		
		panelButton.add(buttonDelete);
		panelButton.add(buttonCheckout);
		
		panelTotal.add(panelField);
		panelTotal.add(panelButton);
		
		//panelContainer.add(panelTitle);
		panelContainer.	add(panelTable);
		panelContainer.add(panelTotal);
		
		this.add(panelContainer,"Center");
		//this.add(panelTotal, "South");
	}

	public cart() {
		this.setLayout(new BorderLayout());
		this.setTitle("Cart");
		this.setSize(500, 350);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setVisible(true);
		initComponent();
		setComponent();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if(table.getSelectedRow() != -1){
			labelNameIsi.setText(table.getValueAt(table.getSelectedRow(), 0).toString());
			//quantity.setValue(table.getValueAt(table.getSelectedRow(), 3).toString());
			labelPriceIsi.setText(table.getValueAt(table.getSelectedRow(), 2).toString());
		}
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() == buttonDelete){
			if(table.getSelectedRow() != -1){
				String nameItem = table.getValueAt(table.getSelectedRow(), 1).toString();
				String query3 = "DELETE FROM `cart` WHERE `cName` LIKE '"+nameItem+"'";
				//String query4 = "DELETE FROM 'mycart' WHERE"
				con.executeUpdate(query3);
				JOptionPane.showMessageDialog(this, "You have successfully remove from cart!");
				viewData();
			}
		}else if(e.getSource() == buttonCheckout){
			if(table.getSelectedRow() != -1){
				String idItem = table.getValueAt(table.getSelectedRow(), 0).toString();
				String nameItem = table.getValueAt(table.getSelectedRow(), 1).toString();
				String priceItem = table.getValueAt(table.getSelectedRow(), 2).toString();
				String quantityItem = table.getValueAt(table.getSelectedRow(), 3).toString();
				
				int result = JOptionPane.showConfirmDialog(this, "Are you sure want to chekcout?","Warning", JOptionPane.YES_NO_OPTION);
				if(result == JOptionPane.YES_OPTION){
					String query5 = "SELECT * FROM `DetailTransaction`";
					con.rs = con.executeQuery(query5);
						String transactionId = "";
					try {
						String query8 = "SELECT RIGHT(TransactionID, 3) AS transactionID FROM detailtransaction ORDER BY TransactionID DESC LIMIT 1";
						
						
						con.rs = con.executeQuery(query8);
						
						while (con.rs.next()) {
							String helo = con.rs.getString("TransactionID");
							if(helo == null){
								transactionId = "US001";
							}else{
								int id = Integer.parseInt(helo) + 1;
							
								if(id < 10 || id > 0){
									transactionId = "TI00"+ Integer.toString(id);
								}else if(id > 9 || id < 100){
									transactionId = "TI0"+ Integer.toString(id);
								}else if(id > 99 || id < 1000){
									transactionId = "TI"+ Integer.toString(id);
								}
							}
						}	
					} catch (NumberFormatException | SQLException e1) {
						e1.printStackTrace();
					}
					String query4 = "INSERT INTO `DetailTransaction`(`TransactionID`, `ProductID`, `Quantity`) VALUES ('"+transactionId+"','"+idItem+"','"+quantityItem+"')";
					con.executeUpdate(query4);
					String query6 = "INSERT INTO `headertransaction`(`TransactionID`, `UserID`) VALUES ('"+transactionId+"','"+masuk.userId+"')";
					con.executeUpdate(query6);
					String query7 = "DELETE FROM `cart`";
					con.executeUpdate(query7);
					JOptionPane.showMessageDialog(this, "You have finished your transaction!");
					viewData();
				}
			}
		}
	
	}

}

