import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class Connect {

    public Statement stmt;
    public ResultSet rs;
    public Connection con;

    public Connect() {
        try{  
            Class.forName("com.mysql.jdbc.Driver");
            con = DriverManager.getConnection("jdbc:mysql://localhost:3306/test","root","");  
            stmt = con.createStatement();  
            
            System.out.println("Connected to the database..");
        }catch(Exception e){ 
            System.out.println(e);
        }  
    }

    public ResultSet executeQuery(String query){
        try{
            rs = stmt.executeQuery(query);
        }
        catch(Exception e){
            System.out.println(e);
        }

        return rs;
    }

    public void executeUpdate(String query){
        try{
            stmt.executeUpdate(query);
        }
        catch(Exception e){
            System.out.println(e);
        }
    }

	public com.mysql.jdbc.PreparedStatement prepareStatement(String sql) {
		// TODO Auto-generated method stub
		return null;
	}
}