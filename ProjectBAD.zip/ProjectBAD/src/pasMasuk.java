
public class pasMasuk {

}
