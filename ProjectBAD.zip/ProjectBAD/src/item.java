import javax.swing.*;

import javax.swing.table.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.sql.SQLException;
import java.util.*;


public class item extends JInternalFrame implements ActionListener, MouseListener {

	Vector<Vector<Object>> tableContent;
	Vector<Object> tableRow, tableHeader;

	JPanel panelContainer, panelTabel, panelTotal, panelTitle, panelField, panelButton;

	JLabel lblTitle, lblTitle2, lblId, lblName, lblPrice, lblCategory;

	JTextField txtId, txtName, txtPrice, txtCategory;
	
	JButton btnReset, btnInsert, btnUpdate, btnDelete;
	
	JTable table = new JTable();
	
	JScrollPane pane;
	
	DefaultTableModel tableModel;
	
	Connect con = new Connect();

	public void addData(String id, String name, int price, String category) {
		tableRow = new Vector<>();
		tableRow.add(id);
		tableRow.add(name);
		tableRow.add(price);
		tableRow.add(category);
		tableContent.add(tableRow);
	}

	public void viewData() {
		tableContent = new Vector<>();
		tableHeader = new Vector<>();

		tableHeader.add("ID");
		tableHeader.add("Name");
		tableHeader.add("Price");
		tableHeader.add("Category");
		
		
		String query = "SELECT * FROM item";
		con.rs = con.executeQuery(query);

		try {
			while (con.rs.next()) {
				addData(con.rs.getString(1), con.rs.getString(2), con.rs.getInt(3), con.rs.getString(4));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		

		tableModel = new DefaultTableModel(tableContent, tableHeader);

		table.setModel(tableModel);

		tableModel.fireTableDataChanged();

	}

	public void initComponent() {
		viewData();

		table.setAutoCreateRowSorter(true);

		pane = new JScrollPane(table);
		
		panelContainer = new JPanel(new GridLayout(2, 1));
		panelTabel = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelTotal = new JPanel(new GridLayout(3, 1));
		panelTitle = new JPanel(new FlowLayout(FlowLayout.CENTER));
		panelField = new JPanel(new GridLayout(4, 2));
		panelButton = new JPanel(new FlowLayout(FlowLayout.CENTER));
		
		lblTitle = new JLabel("Manage Item");
		lblTitle.setFont(new Font("Sans", Font.BOLD,20));
		
		lblTitle2 = new JLabel("Detail");
		lblTitle2.setFont(new Font("Sans", Font.BOLD,20));
		
		lblId = new JLabel("ID");
		txtId = new JTextField();
		
		lblName = new JLabel("Name");
		txtName = new JTextField();
		
		lblPrice = new JLabel("Price");
		txtPrice = new JTextField();
		
		lblCategory = new JLabel("Category");
		txtCategory = new JTextField();
		
		btnReset = new JButton("Reset");
		btnReset.addActionListener(this);
		
		btnInsert = new JButton("Insert");
		btnInsert.addActionListener(this);
		
		btnUpdate = new JButton("Update");
		btnUpdate.addActionListener(this);
		
		btnDelete = new JButton("Delete");
		btnDelete.addActionListener(this);
	}

	public void setComponent() {
		panelTabel.add(lblTitle);
		
		panelTabel.add(pane, "Center");
		
		panelTitle.add(lblTitle2);
		
		panelField.add(lblId);
		panelField.add(txtId);
		
		
		panelField.add(lblName);
		panelField.add(txtName);
		
		
		panelField.add(lblPrice);
		panelField.add(txtPrice);
		
		
		panelField.add(lblCategory);
		panelField.add(txtCategory);
		
		panelButton.add(btnReset);
		panelButton.add(btnInsert);
		panelButton.add(btnUpdate);
		panelButton.add(btnDelete);
		
	
		
		panelTotal.add(panelTitle);
		panelTotal.add(panelField);
		panelTotal.add(panelButton);
		
		panelContainer.add(panelTabel);
		panelContainer.add(panelTotal);
		
		this.add(panelContainer,"Center");
		
	}

	public item() {
		this.setLayout(new BorderLayout());
		this.setTitle("Products");
		this.setSize(500, 500);
		this.setMaximizable(true);
		this.setClosable(true);
		this.setVisible(true);
		initComponent();
		setComponent();
	}

	@Override
	public void mouseClicked(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseEntered(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseExited(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mousePressed(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void mouseReleased(MouseEvent e) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		
		
		String name = txtName.getText();
		String price = txtPrice.getText();
		String category = txtCategory.getText();
		
		
		
		if(e.getSource() == btnInsert){
			if(txtId.getText().length() != 5 && !txtId.getText().startsWith("PR")){
				JOptionPane.showMessageDialog(this, "ID must be like 'PRXXX'", "Error", JOptionPane.ERROR_MESSAGE);
			//}else if(txtId.getText()){
				
			}else if(txtName.getText().length() < 1){
				JOptionPane.showMessageDialog(this, "Item name musn't be null", "Error", JOptionPane.ERROR_MESSAGE);
			}else if(txtPrice.getText().length() < 1){
				JOptionPane.showMessageDialog(this, "Item price musn't be null", "Error", JOptionPane.ERROR_MESSAGE);
			}else if (!txtPrice.getText().matches("[0-9]+")){
				JOptionPane.showMessageDialog(this, "Item price must be numeric", "Error", JOptionPane.ERROR_MESSAGE);
			}else if(txtCategory.getText().length() < 1){
				JOptionPane.showMessageDialog(this, "Item category musn't be null", "Error", JOptionPane.ERROR_MESSAGE);
			}else if(!txtCategory.getText().equals("Food") && !txtCategory.getText().equals("Drink")){
				JOptionPane.showMessageDialog(this, "Item category must be like 'Food' or 'Drink'", "Error", JOptionPane.ERROR_MESSAGE);
			}else{
				String itemId = "";
				
				try{
					String query3 = "SELECT RIGHT(idProduct, 3) AS itemID FROM item ORDER BY idProduct DESC LIMIT 1";
					con.rs = con.executeQuery(query3);
					
					while (con.rs.next()) {
						String helo = con.rs.getString("itemID");
						if(!helo.contains("0")){
							itemId = "PR001";
						}else{
							int id2 = Integer.parseInt(helo) + 1;
						
							if(id2 < 10 || id2 > 0){
								itemId = "PR00"+ Integer.toString(id2);
							}else if(id2 > 9 || id2 < 100){
								itemId = "PR0"+ Integer.toString(id2);
							}else if(id2 > 99 || id2 < 1000){
								itemId = "PR"+ Integer.toString(id2);
							}
						}
					}	
				}catch(SQLException x){
					x.printStackTrace();
				}
				
				String query2 = "INSERT INTO `item`(`idProduct`, `name`, `price`, `category`) VALUES ('"+itemId+"','"+name+"','"+price+"','"+category+"')";
				con.executeUpdate(query2);
				viewData();
			}
		}else if(e.getSource() == btnDelete){
			if(table.getSelectedRow() != -1){
				String nameItem = table.getValueAt(table.getSelectedRow(), 1).toString();
				System.out.println(nameItem);
				String query3 = "DELETE FROM `item` WHERE `name` LIKE '"+nameItem+"'";
				con.executeUpdate(query3);
				viewData();
			}
		}else if(e.getSource() == btnReset){
			String query4 = "DELETE FROM `item`";
			int result = JOptionPane.showConfirmDialog(this, "Are you sure want to reset?","Warning", JOptionPane.YES_NO_OPTION);
			if(result == JOptionPane.YES_OPTION){
				con.executeUpdate(query4);
				viewData();
			}
			
		}else if(e.getSource() == btnUpdate){
			String nameU = txtName.getText();
			String priceU = txtPrice.getText();
			String categoryU = txtCategory.getText();
			
			String idItemU = table.getValueAt(table.getSelectedRow(), 0).toString();
			//String nameItemU = table.getValueAt(table.getSelectedRow(), 1).toString();
			//String priceItemU = table.getValueAt(table.getSelectedRow(), 2).toString();
			//String categoryItemU = table.getValueAt(table.getSelectedRow(), 3).toString();
			
			String query5 = "UPDATE `item` SET `idProduct`= '"+idItemU+"',`name`='"+nameU+"',`price`='"+priceU+"',`category`='"+categoryU+"' WHERE `idProduct`='"+idItemU+"'";
				con.executeUpdate(query5);
				viewData();
		}
		
	}

}	


